# Plan Canvas — framework-native design-build: review bundle

Prepared for external review on 2026-11-27.

| Item | Value |
|---|---|
| Repository | ECC-OPL (`affaan-m/ECC` lineage) |
| Reviewed revision | `9d1697f3` (Phase 8 evidence cross-check) |
| Baseline before this work | `e33a6787~1` |
| Commits in range | 17 |
| Version in tree | 2.2.3 |

This bundle is a curated slice, not a repository snapshot. It contains the plan,
the prose design records, the workflow implementation, the tests that pin its
behaviour, and the acceptance evidence. It excludes `.git/`, `node_modules/`,
caches and anything credential-bearing.

## What the work does

ECC-OPL's design-build workflow originally produced a standalone HTML design
document per section, then a separate implementation of that HTML in the project's
own framework. This work removes that duplication for framework projects: the
section is written **in the project's own component**, rendered by the project's
own dev server, embedded in the existing Plan Canvas, and approved by revision.
The proof gate (G0–G3) then compares the approved revision against the integrated
build for rendered parity.

Two modes exist and are recorded per section:

- `framework-native` — Canvas only iframes a URL; the project compiles its own code.
- legacy HTML — unchanged behaviour for vanilla / standalone-HTML projects.

## What to review, and in what order

1. `docs/plans/framework-native-design-build.plan.md` — the approved plan
   (owner-approved through Plan Canvas; 18 decisions DBN-01…DBN-18, AC-01…AC-20).
2. `docs/design/plan-canvas.md` — the pre-existing Canvas design, for context.
3. `docs/design/phase2-slice.md` … `phase7-compatibility-migration.md` — one record
   per implementation phase, each with its stop condition and honest status.
4. `docs/design/phase8-acceptance-pilots.md` — **start here if reviewing outcomes
   only.** Three pilots, nine negative scenarios, AC matrix, four recorded gaps,
   and a cross-check section that re-derives every numeric claim from the artifacts.
5. `implementation.patch` — the exact diff for the whole range, if you prefer code
   over prose.
6. `pilots/*/artifacts/` — raw receipts, screenshots and JSON the claims rest on.

## Behaviour claims and where they are pinned

| Claim | File |
|---|---|
| Framework/project detection from evidence, never a guess | `scripts/design-build-v2/detect-project.mjs`, `tests/lib/design-build-project-discovery.test.js` |
| Native preview runtime ownership (only processes we started are killed) | `scripts/design-build-v2/preview-runtime.mjs`, `tests/lib/design-build-preview-runtime.test.js` |
| Approval is bound to a revision fingerprint, staleness is rejected | `scripts/design-build-v2/state-machine.mjs`, `tests/lib/design-build-native-state.test.js` |
| Gates G0–G3 and the receipt cannot report false completion | `scripts/design-build-v2/section-gate.mjs`, `scripts/design-build-v2/rendered-authority.mjs`, `tests/design-build-v2-invariants.test.js` |
| Legacy HTML sections are unaffected | `tests/lib/plan-canvas-preview-mode.test.js`, `tests/lib/design-build-section-gate-advance.test.js` |
| Canvas iframe + approve/feedback surface | `scripts/lib/plan-canvas/{ui.js,server.js,sessions.js}` |
| Workflow text the agent follows | `skills/design-build/SKILL.md`, `commands/design-build.md` |

`commands/design-build.md` and `.opencode/commands/design-build.md` are required to
be byte-identical; both are included so that can be checked.

## Results

19 of 20 acceptance criteria VERIFIED. One PARTIAL, by design of the evidence, not
by omission of work:

- **AC-15 (OpenCode + AGY compatibility)** — the OpenCode path ran end-to-end in all
  three pilots; the AGY path has not been executed by the owner.
- Pilot B component/font reuse is PARTIAL because the Laravel scaffold contains no
  component library or custom webfont to reuse.
- Accessibility evidence is an automated axe-core 4.10.2 WCAG 2.2 AA pass (0
  violations after fixing a real contrast defect). No manual screen-reader audit
  was performed.

Do not read any row in this bundle as "framework X is supported" beyond
`react-vite`, `laravel-inertia-react` and `vue-vite`. Every other framework is
`NOT_SUPPORTED` until it is executed.

## Reproducing

Tests (Node 24, no network):

```sh
node --test tests/lib/plan-canvas-*.test.js tests/lib/design-build-*.test.js
```

Pilots need their own stack and are not runnable from this bundle alone — the
pilot sources are not included, only their artifacts and the scripts that produced
them. `pilots/*/BUILD-STATE.md` records the stack, the approved revision and the
exact commands.

Accessibility evidence was produced by loading each pilot URL in Playwright,
injecting `axe-core@4.10.2` (`https://unpkg.com/axe-core@4.10.2/axe.min.js`) and
running tags `wcag2a`, `wcag2aa`, `wcag22aa`. The library itself is not bundled.

## Known limits of this bundle

- Pilot projects lived in `$TMPDIR` and are ephemeral. Everything that was still on
  disk at packing time is included; nothing was reconstructed. If you need a
  missing artifact, it is gone, and no table in the docs should be read as a
  substitute for it.
- The pilot scripts had their absolute repo path rewritten to `<ECC_REPO>` so the
  bundle carries no machine-specific home directory. Substitute your own path if you
  want to run them.
- The bundle carries evidence for three framework variants only.
- No secrets, no `.env`, no guardian/audit logs, no customer data are included.
