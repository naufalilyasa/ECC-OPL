# BUILD-STATE — Pilot C (Vue + Vite)

Secondary pilot: proves Canvas framework-independence, not the full gate path.

| Item | Value |
|---|---|
| Detection | `vue-vite`, `framework-native` |
| Section | `receiving` — `src/App.vue` |
| Revision | `c1` |
| Canvas | iframe → `http://127.0.0.1:5290/`; `h1` "Receiving overview", 3 rows, no page errors |
| Interaction | filter `3 → 1`, counter `1 of 3` |
| Approval | `#approve` verdict `approve`, `verifyApprovalRevision` → `OK` |
| Parity gate | NOT_EXECUTED (out of this pilot's scope) |

Evidence: `artifacts/phase8/`. Run `npm run dev -- --port 5290`, then
`pilot-c-canvas.mjs`.
