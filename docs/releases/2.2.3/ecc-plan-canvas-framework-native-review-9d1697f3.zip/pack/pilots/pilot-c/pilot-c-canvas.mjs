// Phase 8 Pilot C (secondary) — Vue+Vite proves the same Canvas works with a
// non-React framework. Canvas rendering + approval only; no parity gate.
import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'
import { createRequire } from 'node:module'

const REPO = '<ECC_REPO>'
const PILOT = '/private/var/folders/xq/22yplbd15tz0jj4hnsr1m11c0000gp/T/opencode/pilot-c-vue'
const DEV = 'http://127.0.0.1:5290/'
const ART = join(PILOT, 'artifacts/phase8')
mkdirSync(ART, { recursive: true })

const require = createRequire(join(REPO, 'package.json'))
const { chromium } = require('playwright')
const { createSessionStore } = require(join(REPO, 'scripts/lib/plan-canvas/sessions.js'))
const { createPlanCanvasServer } = require(join(REPO, 'scripts/lib/plan-canvas/server.js'))
const { fingerprintNativeReference, verifyApprovalRevision } = await import(
  pathToFileURL(join(REPO, 'scripts/design-build-v2/state-machine.mjs')).href)

const sha = (file) => createHash('sha256').update(readFileSync(join(PILOT, file))).digest('hex')
const reference = () => ({
  files: [
    { kind: 'component-source', path: 'src/App.vue', sha256: sha('src/App.vue') },
    { kind: 'component-imports', path: 'src/main.js', sha256: sha('src/main.js') },
    { kind: 'preview-config', path: 'vite.config.js', sha256: sha('vite.config.js') },
  ],
})
const fp = fingerprintNativeReference(reference())
if (fp.code !== 'OK') throw new Error('fingerprint failed: ' + JSON.stringify(fp))

const artifact = join(PILOT, 'docs/design/sections/vue-receiving.plan.md')
mkdirSync(join(PILOT, 'docs/design/sections'), { recursive: true })
writeFileSync(artifact, '# Vue receiving — Canvas framework-independence check\n')

const store = createSessionStore({ stateDir: join(PILOT, '.canvas-state') })
const server = createPlanCanvasServer({ store, host: '127.0.0.1' })
const { port } = await server.listen(4602)
const opened = await fetch(`http://127.0.0.1:${port}/api/sessions`, {
  method: 'POST', headers: { 'content-type': 'application/json' },
  body: JSON.stringify({
    file: artifact, reopen: true, target: 'opencode',
    previewMode: 'framework-native', previewUrl: DEV,
    previewMeta: { section: 'receiving', revision: 'c1', revisionDigest: fp.revisionDigest, designDigest: fp.designDigest, dataMode: 'fixture' },
  }),
})
const openedBody = await opened.json()
if (opened.status !== 200) throw new Error('open failed: ' + JSON.stringify(openedBody))
const key = openedBody.key
const canvasUrl = `http://127.0.0.1:${port}/canvas/${key}`

const browser = await chromium.launch()
const seen = {}
for (const [label, size] of [['desktop', { width: 1440, height: 900 }], ['mobile', { width: 390, height: 844 }]]) {
  const page = await browser.newPage({ viewport: size })
  const errors = []
  page.on('pageerror', (error) => errors.push(error.message))
  await page.goto(canvasUrl, { waitUntil: 'load' })
  const app = page.frameLocator('#artifact').frameLocator('iframe')
  await app.locator('h1').first().waitFor({ timeout: 25000 })
  seen[label] = {
    h1: (await app.locator('h1').innerText()).trim(),
    rows: await app.locator('tbody tr').count(),
    chip: await page.locator('#modeChip').innerText(),
    errors,
  }
  await page.screenshot({ path: join(ART, `canvas-${label}.png`) })
  if (label === 'desktop') {
    await app.locator('input[type="search"]').fill('Sinar')
    await page.waitForTimeout(200)
    seen.interaction = {
      after: await app.locator('tbody tr').count(),
      counter: (await app.locator('span[aria-live="polite"]').innerText()).trim(),
    }
    await app.locator('input[type="search"]').fill('')
    await page.locator('#approve').click()
    await page.waitForTimeout(600)
  }
  await page.close()
}
await browser.close()

const drained = store.takeFeedback(key)
const items = drained?.items ?? drained?.feedback ?? drained
const verdict = [...items].reverse().find((item) => item.kind === 'verdict')
const session = store.get(key)
const approval = verdict
  ? { verdictId: `canvas:${verdict.id}@${verdict.at}`, approved: verdict.verdict === 'approve', sectionId: 'receiving', revision: 'c1', ...session.previewMeta }
  : null
const bound = approval ? verifyApprovalRevision(approval, reference()) : null
writeFileSync(join(ART, 'pilot-c.json'), JSON.stringify({ key, canvasUrl, fp, seen, items, approval, bound }, null, 2))
console.log('vue', JSON.stringify({ seen, verdict: verdict?.verdict, bound: bound?.code }))
await server.close()
