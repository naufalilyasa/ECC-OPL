// Phase 8 Pilot C gap closure — full native parity gate on the Vue+Vite project.
// Dev capture -> Canvas approval (revision-bound) -> vite build/preview -> gate.
import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs'
import { join } from 'node:path'
import { execFileSync } from 'node:child_process'
import { pathToFileURL } from 'node:url'
import { createRequire } from 'node:module'

const REPO = '<ECC_REPO>'
const PILOT = '/private/var/folders/xq/22yplbd15tz0jj4hnsr1m11c0000gp/T/opencode/pilot-c-vue'
const DEV = 'http://127.0.0.1:5290/'
const PROD = 'http://127.0.0.1:5301/'
const PORT = 4603
const ART = join(PILOT, 'artifacts/phase8')
const BASE = join(ART, 'approved')
const CAND = join(ART, 'candidate')
mkdirSync(BASE, { recursive: true })
mkdirSync(CAND, { recursive: true })

const require = createRequire(join(REPO, 'package.json'))
const { chromium } = require('playwright')
const { createSessionStore } = require(join(REPO, 'scripts/lib/plan-canvas/sessions.js'))
const { createPlanCanvasServer } = require(join(REPO, 'scripts/lib/plan-canvas/server.js'))
const { fingerprintNativeReference, verifyApprovalRevision } = await import(
  pathToFileURL(join(REPO, 'scripts/design-build-v2/state-machine.mjs')).href)
const { ensurePreviewServer, createOwnershipRegistry } = await import(
  pathToFileURL(join(REPO, 'scripts/design-build-v2/preview-runtime.mjs')).href)

const sha = (file) => createHash('sha256').update(readFileSync(join(PILOT, file))).digest('hex')
const shaFile = (file) => createHash('sha256').update(readFileSync(file)).digest('hex')
const reference = () => ({
  files: [
    { kind: 'component-source', path: 'src/App.vue', sha256: sha('src/App.vue') },
    { kind: 'component-imports', path: 'src/main.js', sha256: sha('src/main.js') },
    { kind: 'preview-config', path: 'vite.config.js', sha256: sha('vite.config.js') },
  ],
})
const fp = fingerprintNativeReference(reference())
if (fp.code !== 'OK') throw new Error('fingerprint failed: ' + JSON.stringify(fp))
console.log('vue fingerprint', fp.revisionDigest.slice(0, 12), 'design', fp.designDigest.slice(0, 12))

const artifact = join(PILOT, 'docs/design/sections/receiving.plan.md')
writeFileSync(artifact, '# Section receiving (Vue)\n\nApproved component is `src/App.vue`; no HTML design document is generated.\n')

const store = createSessionStore({ stateDir: join(PILOT, '.canvas-state') })
const server = createPlanCanvasServer({ store, host: '127.0.0.1' })
const { port } = await server.listen(PORT)
const opened = await fetch(`http://127.0.0.1:${port}/api/sessions`, {
  method: 'POST', headers: { 'content-type': 'application/json' },
  body: JSON.stringify({
    file: artifact, reopen: true, target: 'opencode',
    previewMode: 'framework-native', previewUrl: DEV,
    previewMeta: {
      section: 'receiving', revision: 'c1',
      revisionDigest: fp.revisionDigest, designDigest: fp.designDigest, dataMode: 'fixture',
    },
  }),
})
const body = await opened.json()
if (opened.status !== 200) throw new Error('open failed: ' + JSON.stringify(body))
const key = body.key
const canvasUrl = `http://127.0.0.1:${port}/canvas/${key}`

const VIEWPORTS = {
  'desktop-1440': [1440, 900], 'desktop-1280': [1280, 900], 'tablet-768': [768, 1024],
  'mobile-390': [390, 844], 'mobile-360': [360, 800],
}
const ROWS = [
  ['#app', 'display', 'rootDisplay'],
  ['h1', 'font-size', 'h1FontSize'],
  ['main', 'padding-top', 'mainPaddingTop'],
  ['table', 'border-collapse', 'tableCollapse'],
  ['input[type="search"]', 'border-radius', 'filterRadius'],
]
const measure = async (page) => page.evaluate((pairs) => Object.fromEntries(pairs.map(([sel, prop]) => {
  const el = document.querySelector(sel)
  return [prop, el ? getComputedStyle(el).getPropertyValue(prop) : null]
})), ROWS.map(([sel, prop]) => [sel, prop]))

const browser = await chromium.launch()
const devShots = {}
const devMeasure = {}
for (const [vp, [width, height]] of Object.entries(VIEWPORTS)) {
  const page = await browser.newPage({ viewport: { width, height } })
  const errors = []
  page.on('pageerror', (e) => errors.push(e.message))
  const res = await page.goto(DEV, { waitUntil: 'networkidle' })
  await page.waitForSelector('tbody tr')
  const file = join(BASE, `${vp}.png`)
  await page.screenshot({ path: file })
  devShots[vp] = { file, sha256: shaFile(file) }
  devMeasure[vp] = { ...(await measure(page)), status: res.status(), errors }
  await page.close()
}

let interaction = null
const canvasPage = await browser.newPage({ viewport: { width: 1440, height: 900 } })
await canvasPage.goto(canvasUrl, { waitUntil: 'load' })
const app = canvasPage.frameLocator('#artifact').frameLocator('iframe')
await app.locator('h1').first().waitFor({ timeout: 25000 })
const chip = await canvasPage.locator('#modeChip').innerText()
const canvasH1 = (await app.locator('h1').first().innerText()).trim()
const before = await app.locator('tbody tr').count()
await app.locator('input[type="search"]').fill('Sinar')
await canvasPage.waitForTimeout(250)
const after = await app.locator('tbody tr').count()
const counter = (await app.locator('span[aria-live="polite"]').innerText()).trim()
interaction = {
  name: 'filter-rows', applicable: true, observed: after === 1 && before === 3,
  value: `rows:${before}->${after} ${counter}`, before: `${before} rows`, after: `${after} row`,
}
await app.locator('input[type="search"]').fill('')
await canvasPage.waitForTimeout(200)
await canvasPage.screenshot({ path: join(ART, 'canvas-gate.png') })
await canvasPage.locator('#approve').click()
await canvasPage.waitForTimeout(700)
await canvasPage.close()
await browser.close()

const drained = store.takeFeedback(key)
const items = drained?.items ?? drained?.feedback ?? drained
const verdict = [...items].reverse().find((item) => item.kind === 'verdict')
if (!verdict || verdict.verdict !== 'approve') throw new Error('no approval verdict: ' + JSON.stringify(items))
const session = store.get(key)
const approval = {
  verdictId: `canvas:${verdict.id}@${verdict.at}`, approved: true,
  sectionId: 'receiving', revision: 'c1', ...session.previewMeta,
}
const bound = verifyApprovalRevision(approval, reference())
const componentPath = join(PILOT, 'src/App.vue')
const original = readFileSync(componentPath)
writeFileSync(componentPath, Buffer.concat([original, Buffer.from('\n<!-- drift-probe -->\n')]))
const stale = verifyApprovalRevision(approval, reference())
writeFileSync(componentPath, original)
const restored = verifyApprovalRevision(approval, reference())
console.log('binding', bound.code, '| edit', stale.code, '| restore', restored.code)
await server.close()

const build = execFileSync('npm', ['run', 'build'], { cwd: PILOT, encoding: 'utf8', stdio: 'pipe' })
const registry = createOwnershipRegistry()
const preview = await ensurePreviewServer({
  urls: [PROD], command: 'npx vite preview --port 5301 --strictPort --host 127.0.0.1',
  cwd: PILOT, registry, timeoutMs: 40000, intervalMs: 300,
})
if (preview.code) throw new Error('preview failed: ' + preview.code)

const browser2 = await chromium.launch()
const candidateShots = {}
const measurements = []
let prodHtml = null
for (const [vp, [width, height]] of Object.entries(VIEWPORTS)) {
  const page = await browser2.newPage({ viewport: { width, height } })
  const res = await page.goto(PROD, { waitUntil: 'networkidle' })
  await page.waitForSelector('tbody tr')
  if (vp === 'desktop-1440') prodHtml = await page.content().then((html) => ({
    builtAsset: /\/assets\/index-[^"]+\.js/.test(html), noViteClient: !/\/@vite\/client/.test(html),
  }))
  const file = join(CAND, `${vp}.png`)
  await page.screenshot({ path: file })
  candidateShots[vp] = { file, sha256: shaFile(file), status: res.status() }
  const actual = await measure(page)
  for (const [sel, prop, field] of ROWS) {
    const expected = devMeasure[vp][prop]
    measurements.push({
      profile: vp, state: 'default', landmark: sel, property: prop,
      expected, actual: actual[prop], verdict: expected === actual[prop] ? 'PASS' : 'FAIL',
    })
  }
  await page.close()
}
await browser2.close()

const contractChecks = [
  { name: 'contract:vue-render', observed: canvasH1 === 'Receiving overview' },
  { name: 'contract:filter-row', observed: interaction.observed },
  { name: 'contract:responsive-parity', observed: measurements.every((row) => row.verdict === 'PASS') },
  { name: 'contract:no-console-errors', observed: Object.values(devMeasure).every((v) => v.errors.length === 0) },
]

const request = {
  projectRoot: PILOT,
  identity: { sectionId: 'receiving', revision: 'c1', bundleSha256: fp.revisionDigest },
  active: {
    sectionId: 'receiving', revision: 'c1', approvedBundleSha256: fp.revisionDigest,
    state: 'PARITY_PASS', current: 0, steps: ['receiving'],
    previewMode: 'framework-native', designDigest: fp.designDigest, dataMode: 'fixture',
  },
  canvasApproval: {
    verdictId: approval.verdictId, approved: true, sectionId: 'receiving', revision: 'c1',
    bundleSha256: fp.revisionDigest, revisionDigest: fp.revisionDigest, designDigest: fp.designDigest,
  },
  baselineDesignDigest: fp.designDigest,
  nativeReference: reference(),
  candidateFiles: { 'src/App.vue': 'src/App.vue' },
  frameworkCompleteEvidence: { identitySha256: sha('src/App.vue') },
  contractChecks,
  profileDimensions: VIEWPORTS,
  requiredViewports: Object.keys(VIEWPORTS),
  viewportEvidence: Object.fromEntries(Object.entries(candidateShots).map(([vp, shot]) => [vp, {
    screenshot: devShots[vp].file, candidateScreenshot: shot.file,
    measurements: measurements.filter((row) => row.profile === vp),
  }])),
  interactionChecks: [interaction],
  receipt: {
    schemaVersion: 2, sectionId: 'receiving', revision: 'c1',
    approvedBundleSha256: fp.revisionDigest,
    candidateFileHashes: { 'src/App.vue': sha('src/App.vue') },
    measurements,
    viewportScreenshots: Object.fromEntries(Object.entries(devShots).map(([vp, s]) => [vp, s.sha256])),
    gateResults: { G0_preflight: 'PASS', G1_contract: 'PASS', G2_rendered_fidelity: 'PASS', G3_state_interaction: 'PASS' },
    overallVerdict: 'PARITY_PASS',
  },
}
const reqFile = join(ART, 'section-gate-request.json')
writeFileSync(reqFile, JSON.stringify(request, null, 2))
let gate
try {
  const out = execFileSync(process.execPath,
    [join(REPO, 'scripts/design-build-v2/section-gate.mjs'), reqFile], { encoding: 'utf8', stdio: 'pipe' })
  gate = { code: 0, out: JSON.parse(out) }
} catch (error) {
  gate = { code: error.status ?? 1, out: error.stdout ? JSON.parse(error.stdout) : null, err: (error.stderr ?? '').slice(-800) }
}
console.log('gate exit', gate.code, '| receipt', gate.out?.receipt?.code, '| g2', gate.out?.g2?.code, '| state', gate.out?.checkpoint?.state)

writeFileSync(join(ART, 'pilot-c-gate.json'), JSON.stringify({
  key, canvasUrl, chip, fp, approval, bound, stale, restored,
  buildTail: build.trim().split('\n').slice(-6).join('\n'),
  prodHtml, interaction, devMeasure, measurements, gate,
  cleaned: registry.cleanup(),
}, null, 2))
console.log('measurements PASS', measurements.every((r) => r.verdict === 'PASS'), '| prod', JSON.stringify(prodHtml))
