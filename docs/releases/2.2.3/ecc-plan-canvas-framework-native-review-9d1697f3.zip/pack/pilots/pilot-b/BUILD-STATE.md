# BUILD-STATE — Pilot B (Laravel + Inertia React)

Disposable representative project scaffolded outside the product for ECC-OPL
Phase 8. Rlogic is untouched.

| Item | Value |
|---|---|
| Stack | Laravel 13.44.1, Inertia React 3, Vite 8, Tailwind 4 |
| Detection | `laravel-inertia-react`, `framework-native` |
| Section | `receiving` — `resources/js/Pages/Receiving.jsx` |
| Data | `ReceivingData::bag()` → `database/fixtures/receiving.json` (`dataMode: fixture`) |
| Approved revision | `r1` — revisionDigest `ed993f4e…`, designDigest `ffeb6256…` |
| Servers | `php artisan serve` :8000 (user-owned), `npm run dev` :5273 (dev only) |
| Approval | Canvas `#approve` over the live Inertia render |
| Staleness | edit page component → `STALE_REVISION`; restore → `OK` |
| Production render | hot file removed, `npm run build`, Laravel manifest serves `/build/assets/*` (no `@vite/client`) |
| Gate | exit 0, G0–G3 PASS, G2 `PARITY_PASS` (25 rows, 0 drift), `SECTION_COMPLETE` |
| HTML design docs | 0 |
| Production DB adapter | seam only, throws by design — PARTIAL, never executed |

Evidence: `artifacts/phase8/`. Rerun with `pilot-b-step1.mjs` after starting both
servers; the script stops Vite itself before the production build.
