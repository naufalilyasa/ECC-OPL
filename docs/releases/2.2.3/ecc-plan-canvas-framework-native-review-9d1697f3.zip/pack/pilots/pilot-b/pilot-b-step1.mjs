// Phase 8 Pilot B — Laravel + Inertia React, disposable representative project.
// Dev render -> Canvas approval bound to the reviewed revision -> production build
// -> rendered parity gate, all on the real two-process Inertia stack.
import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync, mkdirSync, rmSync, existsSync, readdirSync } from 'node:fs'
import { join } from 'node:path'
import { execFileSync, spawnSync } from 'node:child_process'
import { pathToFileURL } from 'node:url'
import { createRequire } from 'node:module'

const REPO = '<ECC_REPO>'
const PILOT = '/private/var/folders/xq/22yplbd15tz0jj4hnsr1m11c0000gp/T/opencode/pilot-b-laravel'
const DEV = 'http://127.0.0.1:8000/'
const PORT = 4601
const ART = join(PILOT, 'artifacts/phase8')
const BASELINE = join(ART, 'approved')
const CAND = join(ART, 'candidate')
mkdirSync(BASELINE, { recursive: true })
mkdirSync(CAND, { recursive: true })

const require = createRequire(join(REPO, 'package.json'))
const { chromium } = require('playwright')
const { createSessionStore } = require(join(REPO, 'scripts/lib/plan-canvas/sessions.js'))
const { createPlanCanvasServer } = require(join(REPO, 'scripts/lib/plan-canvas/server.js'))
const { fingerprintNativeReference, verifyApprovalRevision } = await import(
  pathToFileURL(join(REPO, 'scripts/design-build-v2/state-machine.mjs')).href)

const COMPONENT = 'resources/js/Pages/Receiving.jsx'
const sha = (file) => createHash('sha256').update(readFileSync(join(PILOT, file))).digest('hex')
const shaFile = (file) => createHash('sha256').update(readFileSync(file)).digest('hex')
const reference = () => ({
  files: [
    { kind: 'component-source', path: COMPONENT, sha256: sha(COMPONENT) },
    { kind: 'component-imports', path: 'resources/js/app.jsx', sha256: sha('resources/js/app.jsx') },
    { kind: 'preview-config', path: 'vite.config.js', sha256: sha('vite.config.js') },
    { kind: 'design-contract', path: 'docs/design/sections/receiving/CONTRACT.md', sha256: sha('docs/design/sections/receiving/CONTRACT.md') },
    { kind: 'data-fixture', path: 'database/fixtures/receiving.json', sha256: sha('database/fixtures/receiving.json') },
  ],
})

const fp = fingerprintNativeReference(reference())
if (fp.code !== 'OK') throw new Error('fingerprint failed: ' + JSON.stringify(fp))
console.log('r1 fingerprint', fp.revisionDigest.slice(0, 12), 'design', fp.designDigest.slice(0, 12))

const artifact = join(PILOT, 'docs/design/sections/receiving.plan.md')
writeFileSync(artifact, [
  '# Section receiving — plan', '',
  '1. Inertia page `Receiving` renders fixture props from `ReceivingData::bag()`.',
  '2. Section is approved in Canvas against the live Laravel + Vite render.',
  '3. The same component file is what integration ships; no HTML design document is generated.', '',
].join('\n'))

const store = createSessionStore({ stateDir: join(PILOT, '.canvas-state') })
const server = createPlanCanvasServer({ store, host: '127.0.0.1' })
const { port } = await server.listen(PORT)

const opened = await fetch(`http://127.0.0.1:${port}/api/sessions`, {
  method: 'POST',
  headers: { 'content-type': 'application/json' },
  body: JSON.stringify({
    file: artifact, reopen: true, target: 'opencode',
    previewMode: 'framework-native', previewUrl: DEV,
    previewMeta: {
      section: 'receiving', revision: 'r1',
      revisionDigest: fp.revisionDigest, designDigest: fp.designDigest, dataMode: 'fixture',
    },
  }),
})
const openedBody = await opened.json()
if (opened.status !== 200) throw new Error('open failed: ' + JSON.stringify(openedBody))
const key = openedBody.key
const canvasUrl = `http://127.0.0.1:${port}/canvas/${key}`
console.log('session', key, canvasUrl)

const VIEWPORTS = {
  'desktop-1440': [1440, 900], 'desktop-1280': [1280, 900], 'tablet-768': [768, 1024],
  'mobile-390': [390, 844], 'mobile-360': [360, 800],
}
const ROWS = [
  ['#app', 'display', 'rootDisplay'],
  ['h1', 'font-size', 'h1FontSize'],
  ['main', 'padding-top', 'mainPaddingTop'],
  ['table', 'border-collapse', 'tableCollapse'],
  ['input[type="search"]', 'border-radius', 'filterRadius'],
]
const measure = async (page) => page.evaluate((pairs) => Object.fromEntries(pairs.map(([sel, prop]) => {
  const el = document.querySelector(sel)
  return [prop, el ? getComputedStyle(el).getPropertyValue(prop) : null]
})), ROWS.map(([sel, prop]) => [sel, prop]))

const browser = await chromium.launch()
const devShots = {}
const devMeasure = {}
let interaction = null
let shellEvidence = null

for (const [vp, [width, height]] of Object.entries(VIEWPORTS)) {
  const page = await browser.newPage({ viewport: { width, height } })
  const consoleErrors = []
  page.on('pageerror', (error) => consoleErrors.push(error.message))
  page.on('console', (msg) => { if (msg.type() === 'error') consoleErrors.push(msg.text()) })
  const response = await page.goto(DEV, { waitUntil: 'networkidle' })
  await page.waitForSelector('tbody tr')
  const file = join(BASELINE, `${vp}.png`)
  await page.screenshot({ path: file })
  devShots[vp] = { file, sha256: shaFile(file) }
  devMeasure[vp] = { ...(await measure(page)), httpStatus: response.status(), consoleErrors }
  if (vp === 'desktop-1440') {
    shellEvidence = {
      dataPage: await page.evaluate(() => {
        const script = document.querySelector('script[data-page="app"]')
        return script ? JSON.parse(script.textContent) : null
      }).then((page) => page?.component ?? null),
      dataMode: await page.evaluate(() => {
        const script = document.querySelector('script[data-page="app"]')
        return script ? JSON.parse(script.textContent).props?.dataMode ?? null : null
      }),
      sidebar: await page.locator('aside').count(),
      tailwindLoaded: await page.evaluate(() => [...document.styleSheets].some((s) => (s.href || '').includes('/build/') || (s.href || '').includes('app.css'))),
      h1: (await page.locator('h1').innerText()).trim(),
    }
    const before = await page.locator('tbody tr').count()
    await page.fill('input[type="search"]', 'Sinar')
    await page.waitForTimeout(200)
    const after = await page.locator('tbody tr').count()
    const counter = (await page.locator('span[aria-live="polite"]').innerText()).trim()
    await page.fill('input[type="search"]', '')
    await page.waitForTimeout(200)
    const restored = await page.locator('tbody tr').count()
    interaction = {
      name: 'filter-rows', applicable: true, observed: after === 1 && restored === before,
      value: `rows:${before}->${after}->${restored} ${counter}`,
      before: `${before} rows`, after: `${after} row`,
    }
  }
  await page.close()
}

// Owner approves the revision Canvas is showing.
const canvasPage = await browser.newPage({ viewport: { width: 1440, height: 900 } })
await canvasPage.goto(canvasUrl, { waitUntil: 'load' })
const app = canvasPage.frameLocator('#artifact').frameLocator('iframe')
await app.locator('h1').first().waitFor({ timeout: 25000 })
const chip = await canvasPage.locator('#modeChip').innerText()
await canvasPage.screenshot({ path: join(ART, 'canvas-r1.png') })
await canvasPage.locator('#approve').click()
await canvasPage.waitForTimeout(700)
await canvasPage.screenshot({ path: join(ART, 'canvas-r1-approved.png') })
await canvasPage.close()
await browser.close()

const drained = store.takeFeedback(key)
const items = drained?.items ?? drained?.feedback ?? drained
const verdict = [...items].reverse().find((item) => item.kind === 'verdict')
if (!verdict || verdict.verdict !== 'approve') throw new Error('no approval verdict: ' + JSON.stringify(items))
const session = store.get(key)
const approval = {
  verdictId: `canvas:${verdict.id}@${verdict.at}`, approved: true,
  sectionId: 'receiving', revision: 'r1', ...session.previewMeta,
}
const bound = verifyApprovalRevision(approval, reference())
const componentPath = join(PILOT, COMPONENT)
const original = readFileSync(componentPath)
writeFileSync(componentPath, Buffer.concat([original, Buffer.from('\n// drift-probe\n')]))
const stale = verifyApprovalRevision(approval, reference())
writeFileSync(componentPath, original)
const restoredBinding = verifyApprovalRevision(approval, reference())
console.log('binding', bound.code, '| after edit', stale.code, '| restored', restoredBinding.code)
await server.close()

// Production render: drop the Vite hot file, build, and let Laravel serve the manifest.
const vitePids = spawnSync('lsof', ['-ti:5273'], { encoding: 'utf8' }).stdout?.trim()
if (vitePids) for (const pid of vitePids.split('\n')) { try { process.kill(Number(pid), 'SIGTERM') } catch { /* gone */ } }
const hot = join(PILOT, 'public/hot')
if (existsSync(hot)) rmSync(hot)
const build = spawnSync('npm', ['run', 'build'], { cwd: PILOT, encoding: 'utf8' })
console.log('build exit', build.status)
if (build.status !== 0) throw new Error('build failed: ' + (build.stdout + build.stderr).slice(-800))
const typecheck = spawnSync('npx', ['tsc', '--noEmit'], { cwd: PILOT, encoding: 'utf8' })

const browser2 = await chromium.launch()
const candidateShots = {}
const candidateMeasure = {}
const measurements = []
let productionHtml = null
for (const [vp, [width, height]] of Object.entries(VIEWPORTS)) {
  const page = await browser2.newPage({ viewport: { width, height } })
  const response = await page.goto(DEV, { waitUntil: 'networkidle' })
  await page.waitForSelector('tbody tr')
  if (vp === 'desktop-1440') productionHtml = await page.content().then((html) => ({
    builtAsset: /\/build\/assets\//.test(html), noViteClient: !/\/@vite\/client/.test(html),
  }))
  const file = join(CAND, `${vp}.png`)
  await page.screenshot({ path: file })
  candidateShots[vp] = { file, sha256: shaFile(file), httpStatus: response.status() }
  const actual = await measure(page)
  candidateMeasure[vp] = actual
  for (const [sel, prop] of ROWS) {
    const expected = devMeasure[vp][prop]
    measurements.push({
      profile: vp, state: 'default', landmark: sel, property: prop,
      expected, actual: actual[prop], verdict: expected === actual[prop] ? 'PASS' : 'FAIL',
    })
  }
  await page.close()
}
await browser2.close()

const contractChecks = [
  { name: 'contract:inertia-page', observed: shellEvidence.dataPage === 'Receiving' },
  { name: 'contract:app-shell', observed: shellEvidence.sidebar === 1 },
  { name: 'contract:stats-and-table', observed: shellEvidence.h1 === 'Receiving overview' },
  { name: 'contract:filter-row', observed: interaction.observed },
  { name: 'contract:responsive-parity', observed: measurements.every((row) => row.verdict === 'PASS') },
]

const request = {
  projectRoot: PILOT,
  identity: { sectionId: 'receiving', revision: 'r1', bundleSha256: fp.revisionDigest },
  active: {
    sectionId: 'receiving', revision: 'r1', approvedBundleSha256: fp.revisionDigest,
    state: 'PARITY_PASS', current: 0, steps: ['receiving'],
    previewMode: 'framework-native', designDigest: fp.designDigest, dataMode: 'fixture',
  },
  canvasApproval: {
    verdictId: approval.verdictId, approved: true, sectionId: 'receiving', revision: 'r1',
    bundleSha256: fp.revisionDigest, revisionDigest: fp.revisionDigest, designDigest: fp.designDigest,
  },
  baselineDesignDigest: fp.designDigest,
  nativeReference: reference(),
  candidateFiles: { [COMPONENT]: COMPONENT },
  frameworkCompleteEvidence: { identitySha256: sha(COMPONENT) },
  contractChecks,
  profileDimensions: VIEWPORTS,
  requiredViewports: Object.keys(VIEWPORTS),
  viewportEvidence: Object.fromEntries(Object.entries(candidateShots).map(([vp, shot]) => [vp, {
    screenshot: devShots[vp].file, candidateScreenshot: shot.file,
    measurements: measurements.filter((row) => row.profile === vp),
  }])),
  interactionChecks: [interaction],
  receipt: {
    schemaVersion: 2, sectionId: 'receiving', revision: 'r1',
    approvedBundleSha256: fp.revisionDigest,
    candidateFileHashes: { [COMPONENT]: sha(COMPONENT) },
    measurements,
    viewportScreenshots: Object.fromEntries(Object.entries(devShots).map(([vp, shot]) => [vp, shot.sha256])),
    gateResults: { G0_preflight: 'PASS', G1_contract: 'PASS', G2_rendered_fidelity: 'PASS', G3_state_interaction: 'PASS' },
    overallVerdict: 'PARITY_PASS',
  },
}
const reqFile = join(ART, 'section-gate-request.json')
writeFileSync(reqFile, JSON.stringify(request, null, 2))
let gate
try {
  const out = execFileSync(process.execPath,
    [join(REPO, 'scripts/design-build-v2/section-gate.mjs'), reqFile], { encoding: 'utf8', stdio: 'pipe' })
  gate = { code: 0, out: JSON.parse(out) }
} catch (error) {
  gate = { code: error.status ?? 1, out: error.stdout ? JSON.parse(error.stdout) : null, err: (error.stderr ?? '').slice(-800) }
}
console.log('gate exit', gate.code, '| receipt', gate.out?.receipt?.code, '| g2', gate.out?.g2?.code, '| state', gate.out?.checkpoint?.state)

const manifest = JSON.parse(readFileSync(join(PILOT, 'public/build/manifest.json'), 'utf8'))
const result = {
  key, canvasUrl, chip, fp, approval, bound, stale, restoredBinding,
  build: { status: build.status, tail: (build.stdout + build.stderr).trim().split('\n').slice(-8).join('\n') },
  typecheck: { status: typecheck.status, tail: (typecheck.stdout + typecheck.stderr).trim().split('\n').slice(-8).join('\n') },
  shellEvidence, productionHtml, interaction,
  devMeasure, candidateMeasure, measurements,
  manifestEntry: manifest['resources/js/app.jsx'] ?? null,
  gate,
  htmlFiles: readdirSync(join(PILOT, 'docs/design/sections'), { recursive: true }).filter((f) => f.endsWith('.html')),
}
writeFileSync(join(ART, 'pilot-b.json'), JSON.stringify(result, null, 2))
console.log('measurements PASS', measurements.every((row) => row.verdict === 'PASS'), '| parity', JSON.stringify(productionHtml))
