// Phase 8 Pilot A — step 1: native Canvas session on a live Vite dev server,
// proof the iframe renders the real app, then a change request through the UI.
import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'
import { createRequire } from 'node:module'

const REPO = '<ECC_REPO>'
const PILOT = '/private/var/folders/xq/22yplbd15tz0jj4hnsr1m11c0000gp/T/opencode/design-build-pilot-react'
const DEV = 'http://127.0.0.1:5199/'
const PORT = 4599
const ART = join(PILOT, 'artifacts/phase8')
mkdirSync(ART, { recursive: true })

const require = createRequire(join(REPO, 'package.json'))
const { chromium } = require('playwright')
const { createSessionStore } = require(join(REPO, 'scripts/lib/plan-canvas/sessions.js'))
const { createPlanCanvasServer } = require(join(REPO, 'scripts/lib/plan-canvas/server.js'))
const { fingerprintNativeReference } = await import(
  pathToFileURL(join(REPO, 'scripts/design-build-v2/state-machine.mjs')).href)

const sha = (file) => createHash('sha256').update(readFileSync(join(PILOT, file))).digest('hex')
const reference = () => ({
  files: [
    { kind: 'component-source', path: 'src/sections/01-app-shell.tsx', sha256: sha('src/sections/01-app-shell.tsx') },
    { kind: 'component-imports', path: 'src/main.tsx', sha256: sha('src/main.tsx') },
    { kind: 'preview-config', path: 'vite.config.ts', sha256: sha('vite.config.ts') },
    { kind: 'design-contract', path: 'docs/design/sections/05-inventory/CONTRACT.md', sha256: sha('docs/design/sections/05-inventory/CONTRACT.md') },
    { kind: 'data-fixture', path: 'src/fixtures/inventory.json', sha256: sha('src/fixtures/inventory.json') },
  ],
})

const fp = fingerprintNativeReference(reference())
if (fp.code !== 'OK') throw new Error('fingerprint failed: ' + JSON.stringify(fp))
console.log('r1 fingerprint', fp.revisionDigest.slice(0, 12), 'design', fp.designDigest.slice(0, 12))

const artifact = join(PILOT, 'docs/design/sections/05-inventory.plan.md')
const store = createSessionStore({ stateDir: join(PILOT, '.canvas-state') })
const server = createPlanCanvasServer({ store, host: '127.0.0.1' })
const { port } = await server.listen(PORT)
console.log('canvas server', port)

const opened = await fetch(`http://127.0.0.1:${port}/api/sessions`, {
  method: 'POST',
  headers: { 'content-type': 'application/json' },
  body: JSON.stringify({
    file: artifact,
    reopen: true,
    target: 'opencode',
    previewMode: 'framework-native',
    previewUrl: DEV,
    previewMeta: {
      section: '01-app-shell', revision: 'r1',
      revisionDigest: fp.revisionDigest, designDigest: fp.designDigest, dataMode: 'fixture',
    },
  }),
})
const openedBody = await opened.json()
if (opened.status !== 200) throw new Error('open failed: ' + JSON.stringify(openedBody))
const key = openedBody.key
const canvasUrl = `http://127.0.0.1:${port}/canvas/${key}`
console.log('session', key, canvasUrl)

const browser = await chromium.launch()
const seen = {}
for (const [label, size] of [['desktop', { width: 1440, height: 900 }], ['mobile', { width: 390, height: 844 }]]) {
  const page = await browser.newPage({ viewport: size })
  await page.goto(canvasUrl, { waitUntil: 'load' })
  const frameEl = page.locator('#artifact')
  await frameEl.waitFor({ state: 'attached' })
  const src = await frameEl.getAttribute('src')
  // The native artifact route emits a wrapper document that frames the project
  // dev server, so the real app lives one level deeper.
  const app = page.frameLocator('#artifact').frameLocator('iframe')
  await app.locator('h1').first().waitFor({ timeout: 20000 })
  seen[label] = {
    src,
    frames: page.frames().map((f) => f.url()),
    h1: (await app.locator('h1').first().innerText()).trim(),
    rows: await app.locator('tbody tr').count(),
    chip: await page.locator('#modeChip').innerText().catch(() => null),
  }
  await page.screenshot({ path: join(ART, `canvas-${label}.png`), fullPage: false })
  if (label === 'desktop') {
    // Change request through the real UI, exactly as a reviewer would.
    await page.locator('#changes').click()
    await page.waitForTimeout(400)
    await page.fill('#chatInput', 'CONTRACT asks for a filter row: add a text filter that narrows the table by PO or supplier.')
    await page.locator('#send').click()
    await page.waitForTimeout(400)
    await page.screenshot({ path: join(ART, 'canvas-change-request.png') })
  }
  await page.close()
}
await browser.close()
console.log('rendered', JSON.stringify(seen))

const drained = store.takeFeedback(key)
const feedback = drained?.items ?? drained?.feedback ?? drained
writeFileSync(join(ART, 'step1-feedback.json'), JSON.stringify({ key, canvasUrl, fp, seen, feedback }, null, 2))
console.log('feedback', JSON.stringify(feedback))

await server.close()
