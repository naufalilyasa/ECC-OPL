// Phase 8 Pilot A — step 3: final build, production-rendered verification, gate.
import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync, mkdirSync, readdirSync, existsSync } from 'node:fs'
import { join } from 'node:path'
import { execFileSync } from 'node:child_process'
import { pathToFileURL } from 'node:url'
import { createRequire } from 'node:module'

const REPO = '<ECC_REPO>'
const PILOT = '/private/var/folders/xq/22yplbd15tz0jj4hnsr1m11c0000gp/T/opencode/design-build-pilot-react'
const PROD = 'http://127.0.0.1:5200/'
const ART = join(PILOT, 'artifacts/phase8')
const CAND = join(ART, 'candidate')
mkdirSync(CAND, { recursive: true })

const require = createRequire(join(REPO, 'package.json'))
const { chromium } = require('playwright')
const { ensurePreviewServer, createOwnershipRegistry, probe } = await import(
  pathToFileURL(join(REPO, 'scripts/design-build-v2/preview-runtime.mjs')).href)
const step2 = JSON.parse(readFileSync(join(ART, 'step2.json'), 'utf8'))
const sha = (file) => createHash('sha256').update(readFileSync(join(PILOT, file))).digest('hex')
const shaFile = (file) => createHash('sha256').update(readFileSync(file)).digest('hex')

const run = (cmd, args) => {
  try {
    const out = execFileSync(cmd, args, { cwd: PILOT, encoding: 'utf8', stdio: 'pipe' })
    return { code: 0, out: out.trim().split('\n').slice(-6).join('\n') }
  } catch (error) {
    return { code: error.status ?? 1, out: `${error.stdout ?? ''}${error.stderr ?? ''}`.trim().split('\n').slice(-12).join('\n') }
  }
}
const build = run('npx', ['vite', 'build'])
const typecheck = run('npx', ['tsc', '--noEmit'])
// Negative scenario 2: the scaffold never carried @types/react, and Phase 8
// forbids installing dependencies during a pilot. Recorded as BLOCKED, not fixed.
const typecheckStatus = typecheck.code === 0 ? 'PASS' : 'BLOCKED_MISSING_DEV_DEPENDENCY'
console.log('build', build.code, '| tsc', typecheck.code, typecheckStatus)
if (build.code !== 0) throw new Error('final build failed')

const registry = createOwnershipRegistry()
const server = await ensurePreviewServer({
  urls: [PROD], command: 'npx vite preview --port 5200 --strictPort --host 127.0.0.1',
  cwd: PILOT, registry, timeoutMs: 40000, intervalMs: 300,
})
console.log('preview', JSON.stringify({ started: server.started, reused: server.reused, code: server.code }))
if (server.code) throw new Error('preview failed: ' + server.code)

const ROWS = [
  ['#root', 'display', 'rootDisplay'],
  ['h1', 'font-size', 'h1FontSize'],
  ['table', 'border-collapse', 'tableCollapse'],
  ['main', 'padding-top', 'mainPaddingTop'],
  ['input[type="search"]', 'border-radius', 'filterRadius'],
]
const browser = await chromium.launch()
const viewportEvidence = {}
const rows = []
for (const [vp, [width, height]] of Object.entries({
  'desktop-1440': [1440, 900], 'desktop-1280': [1280, 900], 'tablet-768': [768, 1024],
  'mobile-390': [390, 844], 'mobile-360': [360, 800],
})) {
  const page = await browser.newPage({ viewport: { width, height } })
  await page.goto(PROD, { waitUntil: 'networkidle' })
  await page.waitForSelector('tbody tr')
  const file = join(CAND, `${vp}.png`)
  await page.screenshot({ path: file })
  const actual = await page.evaluate((pairs) => Object.fromEntries(pairs.map(([sel, prop]) => {
    const el = document.querySelector(sel)
    return [prop, el ? getComputedStyle(el).getPropertyValue(prop) : null]
  })), ROWS.map(([sel, prop]) => [sel, prop]))
  const approved = step2.measurements[vp]
  const vpRows = ROWS.map(([sel, prop, field]) => ({
    profile: vp, state: 'default', landmark: sel, property: prop,
    expected: approved[field], actual: Object.fromEntries(ROWS.map(([, p, f]) => [p, actual[p]]))[prop],
    verdict: approved[field] === actual[prop] ? 'PASS' : 'FAIL',
  }))
  rows.push(...vpRows)
  viewportEvidence[vp] = {
    screenshot: step2.viewportShots[vp].file, candidateScreenshot: file, measurements: vpRows,
  }
  await page.close()
}
await browser.close()

const component = 'src/sections/01-app-shell.tsx'
const contractChecks = [
  { name: 'contract:receiving-table', observed: rows.some((r) => r.property === 'border-collapse' && r.actual === 'collapse' && r.verdict === 'PASS') },
  { name: 'contract:filter-row', observed: rows.filter((r) => r.property === 'border-radius' && r.verdict === 'PASS').length === 5 },
  { name: 'contract:responsive-shell', observed: rows.filter((r) => r.property === 'padding-top' && r.actual === '24px').length === 5 },
]

const request = {
  projectRoot: PILOT,
  identity: { sectionId: '01-app-shell', revision: 'r2', bundleSha256: step2.fp.revisionDigest },
  active: {
    sectionId: '01-app-shell', revision: 'r2', approvedBundleSha256: step2.fp.revisionDigest,
    state: 'PARITY_PASS', current: 0, steps: ['01-app-shell'],
    previewMode: 'framework-native', designDigest: step2.fp.designDigest, dataMode: 'fixture',
  },
  canvasApproval: {
    verdictId: step2.approval.verdictId, approved: true,
    sectionId: '01-app-shell', revision: 'r2', bundleSha256: step2.fp.revisionDigest,
    revisionDigest: step2.approval.revisionDigest, designDigest: step2.approval.designDigest,
  },
  baselineDesignDigest: step2.fp.designDigest,
  nativeReference: {
    files: [
      { kind: 'component-source', path: component, sha256: sha(component) },
      { kind: 'component-imports', path: 'src/main.tsx', sha256: sha('src/main.tsx') },
      { kind: 'preview-config', path: 'vite.config.ts', sha256: sha('vite.config.ts') },
      { kind: 'design-contract', path: 'docs/design/sections/05-inventory/CONTRACT.md', sha256: sha('docs/design/sections/05-inventory/CONTRACT.md') },
      { kind: 'data-fixture', path: 'src/fixtures/inventory.json', sha256: sha('src/fixtures/inventory.json') },
    ],
  },
  candidateFiles: { [component]: component },
  frameworkCompleteEvidence: { identitySha256: sha(component) },
  contractChecks,
  profileDimensions: {
    'desktop-1440': [1440, 900], 'desktop-1280': [1280, 900], 'tablet-768': [768, 1024],
    'mobile-390': [390, 844], 'mobile-360': [360, 800],
  },
  requiredViewports: Object.keys(viewportEvidence),
  viewportEvidence,
  interactionChecks: [step2.interaction],
  receipt: {
    schemaVersion: 2, sectionId: '01-app-shell', revision: 'r2',
    approvedBundleSha256: step2.fp.revisionDigest,
    candidateFileHashes: { [component]: sha(component) },
    measurements: rows,
    viewportScreenshots: Object.fromEntries(
      Object.entries(viewportEvidence).map(([vp, v]) => [vp, shaFile(v.screenshot)])),
    gateResults: { G0_preflight: 'PASS', G1_contract: 'PASS', G2_rendered_fidelity: 'PASS', G3_state_interaction: 'PASS' },
    overallVerdict: 'PARITY_PASS',
  },
}
const reqFile = join(ART, 'section-gate-request.json')
writeFileSync(reqFile, JSON.stringify(request, null, 2))

let gate
try {
  const out = execFileSync(process.execPath,
    [join(REPO, 'scripts/design-build-v2/section-gate.mjs'), reqFile], { encoding: 'utf8', stdio: 'pipe' })
  gate = { code: 0, out: JSON.parse(out) }
} catch (error) {
  gate = { code: error.status ?? 1, out: error.stdout ? JSON.parse(error.stdout) : null, err: error.stderr }
}
console.log('gate exit', gate.code, '| receipt', gate.out?.receipt?.code, '| g2', gate.out?.g2?.code, '| state', gate.out?.checkpoint?.state)

const htmlFiles = existsSync(join(PILOT, 'docs/design/sections'))
  ? readdirSync(join(PILOT, 'docs/design/sections'), { recursive: true }).filter((f) => f.endsWith('.html'))
  : []
const imports = readFileSync(join(PILOT, component), 'utf8').match(/from ['"][^'"]+['"]/g) ?? []
const result = {
  build, typecheck, typecheckStatus, gate, htmlFiles,
  imports: [...new Set(imports)],
  packageJson: sha('package.json'),
  devServerAlive: (await probe('http://127.0.0.1:5199/', { timeoutMs: 1500 })).ready,
  contractChecks,
  measurementsPass: rows.every((r) => r.verdict === 'PASS'),
}
writeFileSync(join(ART, 'step3.json'), JSON.stringify(result, null, 2))
console.log('cleanup', JSON.stringify(registry.cleanup()))
console.log('dev server after cleanup', result.devServerAlive, '| html files', htmlFiles.length, '| imports', result.imports.join(','))
