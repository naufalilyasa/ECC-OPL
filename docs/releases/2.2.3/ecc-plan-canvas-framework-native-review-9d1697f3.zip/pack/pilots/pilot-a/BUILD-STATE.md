# BUILD-STATE — Pilot A (React + TS + Vite)

Disposable acceptance pilot for ECC-OPL Phase 8. Standing outside ECC-OPL on
purpose; not a product artifact.

| Item | Value |
|---|---|
| Detection | `react-vite`, `framework-native` |
| Section | `01-app-shell` |
| Approved revision | `r2` — revisionDigest `eda9e03578de…`, designDigest `96862228a3c2…` |
| Approval | Canvas `#approve` over `POST /api/sessions` (real HTTP + real browser) |
| Staleness | edit → `STALE_REVISION`; restore → `OK` |
| Gate | `section-gate.mjs` exit 0, G0–G3 PASS, G2 `PARITY_PASS` (25 rows, 0 drift), `SECTION_COMPLETE` |
| Build | `npx vite build` exit 0 |
| Type check | `npx tsc --noEmit` exit 2 — `@types/react` absent, not installed (Phase 8 rule) → BLOCKED |
| HTML design docs | 0 |
| Change request | Canvas chat asked for a filter row; implemented; re-approved as `r2` |

Evidence: `artifacts/phase8/`. Baseline: `artifacts/baseline/`.
Reload with `npm run dev -- --host 127.0.0.1 --port 5199`.
