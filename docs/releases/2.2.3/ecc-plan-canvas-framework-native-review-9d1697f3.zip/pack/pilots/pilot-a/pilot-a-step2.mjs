// Phase 8 Pilot A — step 2: implement the requested change, re-approve the real
// revision in Canvas, and prove the approval is bound to those exact bytes.
import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'
import { createRequire } from 'node:module'

const REPO = '<ECC_REPO>'
const PILOT = '/private/var/folders/xq/22yplbd15tz0jj4hnsr1m11c0000gp/T/opencode/design-build-pilot-react'
const DEV = 'http://127.0.0.1:5199/'
const PORT = 4599
const ART = join(PILOT, 'artifacts/phase8')
const APPROVED = join(ART, 'approved')
mkdirSync(APPROVED, { recursive: true })

const require = createRequire(join(REPO, 'package.json'))
const { chromium } = require('playwright')
const { createSessionStore } = require(join(REPO, 'scripts/lib/plan-canvas/sessions.js'))
const { createPlanCanvasServer } = require(join(REPO, 'scripts/lib/plan-canvas/server.js'))
const machine = await import(pathToFileURL(join(REPO, 'scripts/design-build-v2/state-machine.mjs')).href)
const { fingerprintNativeReference, verifyApprovalRevision } = machine

const VIEWPORTS = {
  'desktop-1440': [1440, 900],
  'desktop-1280': [1280, 900],
  'tablet-768': [768, 1024],
  'mobile-390': [390, 844],
  'mobile-360': [360, 800],
}
const sha = (file) => createHash('sha256').update(readFileSync(join(PILOT, file))).digest('hex')
const reference = () => ({
  files: [
    { kind: 'component-source', path: 'src/sections/01-app-shell.tsx', sha256: sha('src/sections/01-app-shell.tsx') },
    { kind: 'component-imports', path: 'src/main.tsx', sha256: sha('src/main.tsx') },
    { kind: 'preview-config', path: 'vite.config.ts', sha256: sha('vite.config.ts') },
    { kind: 'design-contract', path: 'docs/design/sections/05-inventory/CONTRACT.md', sha256: sha('docs/design/sections/05-inventory/CONTRACT.md') },
    { kind: 'data-fixture', path: 'src/fixtures/inventory.json', sha256: sha('src/fixtures/inventory.json') },
  ],
})

const fp = fingerprintNativeReference(reference())
if (fp.code !== 'OK') throw new Error('fingerprint failed: ' + JSON.stringify(fp))
console.log('r2 fingerprint', fp.revisionDigest.slice(0, 12), 'design', fp.designDigest.slice(0, 12))

const artifact = join(PILOT, 'docs/design/sections/05-inventory.plan.md')
const store = createSessionStore({ stateDir: join(PILOT, '.canvas-state') })
const server = createPlanCanvasServer({ store, host: '127.0.0.1' })
const { port } = await server.listen(PORT)

const opened = await fetch(`http://127.0.0.1:${port}/api/sessions`, {
  method: 'POST',
  headers: { 'content-type': 'application/json' },
  body: JSON.stringify({
    file: artifact,
    reopen: true,
    target: 'opencode',
    previewMode: 'framework-native',
    previewUrl: DEV,
    previewMeta: {
      section: '01-app-shell', revision: 'r2',
      revisionDigest: fp.revisionDigest, designDigest: fp.designDigest, dataMode: 'fixture',
    },
  }),
})
const openedBody = await opened.json()
if (opened.status !== 200) throw new Error('open failed: ' + JSON.stringify(openedBody))
const key = openedBody.key
const canvasUrl = `http://127.0.0.1:${port}/canvas/${key}`
console.log('session', key, canvasUrl)

const MEASURE = async (frame) => {
  const read = (sel, prop) => frame.evaluate(([s, p]) => {
    const el = document.querySelector(s)
    return el ? getComputedStyle(el).getPropertyValue(p) : null
  }, [sel, prop])
  return {
    rootDisplay: await read('#root', 'display'),
    h1FontSize: await read('h1', 'font-size'),
    tableCollapse: await read('table', 'border-collapse'),
    mainPaddingTop: await read('main', 'padding-top'),
    filterRadius: await read('input[type="search"]', 'border-radius'),
  }
}

const browser = await chromium.launch()
const viewportShots = {}
const measurements = {}
let interaction = null

for (const [vp, [width, height]] of Object.entries(VIEWPORTS)) {
  const page = await browser.newPage({ viewport: { width, height } })
  await page.goto(DEV, { waitUntil: 'networkidle' })
  await page.waitForSelector('tbody tr')
  const file = join(APPROVED, `${vp}.png`)
  await page.screenshot({ path: file })
  viewportShots[vp] = { file, sha256: createHash('sha256').update(readFileSync(file)).digest('hex') }
  measurements[vp] = await MEASURE(page)
  if (vp === 'desktop-1440') {
    const before = await page.locator('tbody tr').count()
    await page.fill('input[type="search"]', 'Sinar')
    await page.waitForTimeout(150)
    const after = await page.locator('tbody tr').count()
    const counter = await page.locator('main span[aria-live="polite"]').innerText()
    await page.fill('input[type="search"]', '')
    await page.waitForTimeout(150)
    interaction = {
      name: 'filter-rows', applicable: true, observed: after === 1,
      value: `rows:${before}->${after} ${counter.trim()}`,
      before: `${before} rows`, after: `${after} row`,
    }
  }
  await page.close()
}

// Owner approves the revision the canvas is showing.
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } })
await page.goto(canvasUrl, { waitUntil: 'load' })
const app = page.frameLocator('#artifact').frameLocator('iframe')
await app.locator('h1').first().waitFor({ timeout: 20000 })
const chip = await page.locator('#modeChip').innerText()
await page.screenshot({ path: join(ART, 'canvas-r2.png') })
await page.locator('#approve').click()
await page.waitForTimeout(600)
await page.screenshot({ path: join(ART, 'canvas-r2-approved.png') })
await page.close()
await browser.close()

const drained = store.takeFeedback(key)
const items = drained?.items ?? drained?.feedback ?? drained
const verdict = [...items].reverse().find((item) => item.kind === 'verdict')
writeFileSync(join(ART, 'step2-verdicts.json'), JSON.stringify({ key, chip, items }, null, 2))
if (!verdict || verdict.verdict !== 'approve') throw new Error('no approval verdict: ' + JSON.stringify(items))

const session = store.get(key)
const approval = {
  verdictId: `canvas:${verdict.id}@${verdict.at}`,
  approved: true,
  sectionId: '01-app-shell',
  revision: 'r2',
  ...session.previewMeta,
}
const bound = verifyApprovalRevision(approval, reference())
console.log('binding at approval', bound.code)

// Negative scenario: a visual reference change after approval must go stale.
const componentPath = join(PILOT, 'src/sections/01-app-shell.tsx')
const original = readFileSync(componentPath)
writeFileSync(componentPath, Buffer.concat([original, Buffer.from('\n// drift-probe\n')]))
const stale = verifyApprovalRevision(approval, reference())
writeFileSync(componentPath, original)
const restored = verifyApprovalRevision(approval, reference())
console.log('after edit', stale.code, 'after restore', restored.code)

writeFileSync(join(ART, 'step2.json'), JSON.stringify({
  key, canvasUrl, chip, approval, fp, bound, stale, restored,
  viewportShots, measurements, interaction, previewMeta: session.previewMeta,
}, null, 2))
await server.close()
