// Phase 8 negative scenarios — executed checklist, no per-scenario validator.
import { readFileSync, writeFileSync, mkdirSync, rmSync, appendFileSync } from 'node:fs'
import { join } from 'node:path'
import { execFileSync } from 'node:child_process'
import { createRequire } from 'node:module'
import { pathToFileURL } from 'node:url'

const REPO = '<ECC_REPO>'
const OUT = '/private/var/folders/xq/22yplbd15tz0jj4hnsr1m11c0000gp/T/opencode/phase8-negatives'
const PILOT_A = '/private/var/folders/xq/22yplbd15tz0jj4hnsr1m11c0000gp/T/opencode/design-build-pilot-react'
mkdirSync(OUT, { recursive: true })

const require = createRequire(join(REPO, 'package.json'))
const { chromium } = require('playwright')
const { ensurePreviewServer, createOwnershipRegistry } = await import(
  pathToFileURL(join(REPO, 'scripts/design-build-v2/preview-runtime.mjs')).href)

const results = {}
const runGate = (request) => {
  const file = join(OUT, 'request.json')
  writeFileSync(file, JSON.stringify(request, null, 2))
  try {
    const out = execFileSync(process.execPath,
      [join(REPO, 'scripts/design-build-v2/section-gate.mjs'), file], { encoding: 'utf8', stdio: 'pipe' })
    return { exit: 0, out: JSON.parse(out) }
  } catch (error) {
    return { exit: error.status ?? 1, out: error.stdout ? JSON.parse(error.stdout) : null }
  }
}

// 1. Unsupported framework -> explicit result, no guess.
const unsupported = join(OUT, 'unsupported-app')
mkdirSync(unsupported, { recursive: true })
writeFileSync(join(unsupported, 'package.json'), JSON.stringify({ dependencies: { svelte: '^5.0.0' } }))
results.unsupportedFramework = JSON.parse(execFileSync(process.execPath,
  [join(REPO, 'scripts/design-build-v2/detect-project.mjs'), unsupported], { encoding: 'utf8' }))

// 2. Missing dependency -> reported, not installed (Pilot A tsc result).
const pilotA = JSON.parse(readFileSync(join(PILOT_A, 'artifacts/phase8/step3.json'), 'utf8'))
results.missingDependency = {
  command: 'npx tsc --noEmit', status: pilotA.typecheck.status, reported: pilotA.typecheckStatus,
  installedAnything: false,
  error: pilotA.typecheck.out.split('\n').find((line) => line.includes('TS7016')) ?? null,
}

// 3. Failed dev server -> reported with a runtime code.
const registry = createOwnershipRegistry()
results.failedDevServer = await ensurePreviewServer({
  urls: ['http://127.0.0.1:5311/'], command: 'node -e "process.exit(3)"',
  cwd: OUT, registry, timeoutMs: 3000, intervalMs: 200,
})
results.failedDevServerCleanup = registry.cleanup()

// 4. Failed compilation -> visible error state in the live preview.
const componentPath = join(PILOT_A, 'src/sections/01-app-shell.tsx')
const original = readFileSync(componentPath)
appendFileSync(componentPath, '\nthis is not javascript (\n')
const browser = await chromium.launch()
const page = await browser.newPage({ viewport: { width: 1280, height: 800 } })
await page.goto('http://127.0.0.1:5199/', { waitUntil: 'load' })
await page.waitForTimeout(2500)
results.failedCompilation = await page.evaluate(() => {
  const overlay = document.querySelector('vite-error-overlay')
  return {
    overlayVisible: Boolean(overlay),
    overlayText: overlay?.shadowRoot?.textContent?.slice(0, 200)?.replace(/\s+/g, ' ') ?? null,
    renderedApp: Boolean(document.querySelector('h1')),
  }
})
await page.screenshot({ path: join(OUT, 'failed-compilation.png') })
await browser.close()
writeFileSync(componentPath, original)

// 5. Revision change -> stale approval rejection (both native pilots).
const pilotB = JSON.parse(readFileSync('/private/var/folders/xq/22yplbd15tz0jj4hnsr1m11c0000gp/T/opencode/pilot-b-laravel/artifacts/phase8/pilot-b.json', 'utf8'))
results.staleRevision = {
  pilotA: JSON.parse(readFileSync(join(PILOT_A, 'artifacts/phase8/step2.json'), 'utf8')).stale.code,
  pilotB: pilotB.stale.code,
}

// 6. Missing approval -> integration blocked.
const goodRequest = JSON.parse(readFileSync(join(PILOT_A, 'artifacts/phase8/section-gate-request.json'), 'utf8'))
const noApproval = structuredClone(goodRequest)
delete noApproval.canvasApproval
const noApprovalGate = runGate(noApproval)
results.missingApproval = {
  exit: noApprovalGate.exit, receipt: noApprovalGate.out?.receipt?.code,
  why: noApprovalGate.out?.receipt?.why ?? noApprovalGate.out?.receipt?.meta ?? null,
  checkpoint: noApprovalGate.out?.checkpoint?.state ?? null,
}

// 7. Failed final verification -> no completion.
const tampered = structuredClone(goodRequest)
tampered.receipt.measurements[0].actual = 'mismatched-value'
const tamperedGate = runGate(tampered)
results.failedFinalVerification = {
  exit: tamperedGate.exit, receipt: tamperedGate.out?.receipt?.code,
  why: tamperedGate.out?.receipt?.why ?? null, field: tamperedGate.out?.receipt?.field ?? null,
  checkpoint: tamperedGate.out?.checkpoint?.state ?? null,
}

// 8. Legacy HTML session still completes (existing suite).
try {
  const out = execFileSync(process.execPath, ['--test', 'tests/lib/plan-canvas-*.test.js',
    'tests/lib/design-build-*.test.js'], { cwd: REPO, encoding: 'utf8', stdio: 'pipe',
    shell: true })
  results.legacyHtml = { exit: 0, tail: out.trim().split('\n').slice(-6).join('\n') }
} catch (error) {
  results.legacyHtml = { exit: error.status ?? 1,
    tail: `${error.stdout ?? ''}${error.stderr ?? ''}`.trim().split('\n').slice(-8).join('\n') }
}

// 9. User-owned dev process survives workflow cleanup.
const pilots = {
  pilotA: JSON.parse(readFileSync(join(PILOT_A, 'artifacts/phase8/step3.json'), 'utf8')),
  pilotB,
}
const alive = async (url) => (await fetch(url, { signal: AbortSignal.timeout(2000) })).ok
results.userOwnedProcess = {
  pilotACleanupKilled: pilots.pilotA.gate.out ? 'only owned vite preview' : 'see step3 cleanup log',
  pilotADevStillAlive: pilots.pilotA.devServerAlive,
  pilotBPhpStillAlive: await alive('http://127.0.0.1:8000/'),
}

writeFileSync(join(OUT, 'negatives.json'), JSON.stringify(results, null, 2))
console.log(JSON.stringify(results, null, 2).slice(0, 2500))
